# UDIS

University Department Information System (UDIS) is a Python based GUI application to store, update and modify various academic and administrative records of a University Department.

## Languages and Frameworks Used

This application uses `Python` for coding purposes, `Tkinter` library of `Python` to design the GUI and `SQLite3` to manage data

# Modes of Operation

To use the application,simply run the `Main.py` file.
The login username is 'purvi' and password is 'password'

## Contibutors

This application has been created by Purvi Baranwal
